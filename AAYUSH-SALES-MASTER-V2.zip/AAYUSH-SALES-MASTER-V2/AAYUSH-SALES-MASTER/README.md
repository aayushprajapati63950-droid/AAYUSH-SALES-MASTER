# AAYUSH SALES MASTER V2

Vyapar-style retail billing/accounting foundation for AAYUSH SALES.

## Included
- Modern Home/Dashboard navigation
- Sale: Cash/Credit, customer, multiple items, qty/unit/rate, discount, paid, due
- Automatic stock reduction on sale
- Invoice history
- Print invoice
- Save invoice as PDF
- Save invoice as PNG image
- Items/stock with sale & purchase rates, unit, GST, opening stock
- Purchase entry with stock increase
- Customers/suppliers
- Payment In / Payment Out
- Expenses
- Reports
- Shop settings
- SQLite offline database
- Android Back returns to AAYUSH SALES Home instead of exiting from inner screens

## Build
Open in Android Studio and build `:app:assembleDebug`.
