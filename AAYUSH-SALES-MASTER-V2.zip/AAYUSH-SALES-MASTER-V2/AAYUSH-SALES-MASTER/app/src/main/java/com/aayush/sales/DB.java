package com.aayush.sales;

import android.content.*;import android.database.*;import android.database.sqlite.*;

public class DB extends SQLiteOpenHelper{
 public DB(Context c){super(c,"aayush_sales_master.db",null,2);}
 public void onCreate(SQLiteDatabase d){
  d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,unit TEXT,rate REAL DEFAULT 0,purchase REAL DEFAULT 0,stock REAL DEFAULT 0,tax REAL DEFAULT 0)");
  d.execSQL("CREATE TABLE parties(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,type TEXT,balance REAL DEFAULT 0)");
  d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,no TEXT,date INTEGER,party_id INTEGER,party_name TEXT,type TEXT,subtotal REAL,discount REAL,tax REAL,total REAL,paid REAL,due REAL)");
  d.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,item_id INTEGER,item_name TEXT,qty REAL,unit TEXT,rate REAL,tax REAL,amount REAL)");
  d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,party_id INTEGER,date INTEGER,type TEXT,amount REAL,note TEXT)");
  d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,date INTEGER,title TEXT,amount REAL,note TEXT)");
  d.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,no TEXT,date INTEGER,supplier_id INTEGER,supplier_name TEXT,subtotal REAL,paid REAL,due REAL)");
  d.execSQL("CREATE TABLE purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_id INTEGER,item_id INTEGER,item_name TEXT,qty REAL,unit TEXT,rate REAL,amount REAL)");
  d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
  d.execSQL("INSERT INTO settings VALUES('shop_name','AAYUSH SALES')");d.execSQL("INSERT INTO settings VALUES('shop_phone','')");d.execSQL("INSERT INTO settings VALUES('shop_address','')");d.execSQL("INSERT INTO settings VALUES('gstin','')");
 }
 public void onUpgrade(SQLiteDatabase d,int a,int b){if(a<2)d.execSQL("CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,no TEXT,date INTEGER,supplier_id INTEGER,supplier_name TEXT,subtotal REAL,paid REAL,due REAL)");if(a<2)d.execSQL("CREATE TABLE IF NOT EXISTS purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_id INTEGER,item_id INTEGER,item_name TEXT,qty REAL,unit TEXT,rate REAL,amount REAL)");}
 public long item(String n,String c,String u,double r,double p,double s,double t){ContentValues v=new ContentValues();v.put("name",n);v.put("code",c);v.put("unit",u);v.put("rate",r);v.put("purchase",p);v.put("stock",s);v.put("tax",t);return getWritableDatabase().insert("items",null,v);}
 public long party(String n,String ph,String ad,String type){ContentValues v=new ContentValues();v.put("name",n);v.put("phone",ph);v.put("address",ad);v.put("type",type);return getWritableDatabase().insert("parties",null,v);}
 public Cursor items(){return getReadableDatabase().query("items",null,null,null,null,null,"name ASC");}
 public Cursor parties(){return getReadableDatabase().query("parties",null,null,null,null,null,"name ASC");}
 public Cursor invoices(){return getReadableDatabase().query("invoices",null,null,null,null,null,"id DESC");}
 public Cursor invoice(long id){return getReadableDatabase().query("invoices",null,"id=?",new String[]{""+id},null,null,null);}
 public Cursor invoiceItems(long id){return getReadableDatabase().query("invoice_items",null,"invoice_id=?",new String[]{""+id},null,null,"id ASC");}
 public double total(String sql){Cursor c=getReadableDatabase().rawQuery(sql,null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
 public long createInvoice(String no,long date,long partyId,String partyName,String type,double sub,double discount,double tax,double total,double paid,double due){ContentValues v=new ContentValues();v.put("no",no);v.put("date",date);v.put("party_id",partyId);v.put("party_name",partyName);v.put("type",type);v.put("subtotal",sub);v.put("discount",discount);v.put("tax",tax);v.put("total",total);v.put("paid",paid);v.put("due",due);return getWritableDatabase().insert("invoices",null,v);}
 public void addInvoiceItem(long inv,long itemId,String name,double qty,String unit,double rate,double tax,double amount){ContentValues v=new ContentValues();v.put("invoice_id",inv);v.put("item_id",itemId);v.put("item_name",name);v.put("qty",qty);v.put("unit",unit);v.put("rate",rate);v.put("tax",tax);v.put("amount",amount);getWritableDatabase().insert("invoice_items",null,v);if(itemId>0)getWritableDatabase().execSQL("UPDATE items SET stock=stock-? WHERE id=?",new Object[]{qty,itemId});}
 public long payment(long partyId,String type,double amount,String note){ContentValues v=new ContentValues();v.put("party_id",partyId);v.put("date",System.currentTimeMillis());v.put("type",type);v.put("amount",amount);v.put("note",note);return getWritableDatabase().insert("payments",null,v);}
 public long expense(String title,double amount,String note){ContentValues v=new ContentValues();v.put("date",System.currentTimeMillis());v.put("title",title);v.put("amount",amount);v.put("note",note);return getWritableDatabase().insert("expenses",null,v);}
 public long purchase(String no,long date,long supplierId,String supplier,double sub,double paid,double due){ContentValues v=new ContentValues();v.put("no",no);v.put("date",date);v.put("supplier_id",supplierId);v.put("supplier_name",supplier);v.put("subtotal",sub);v.put("paid",paid);v.put("due",due);return getWritableDatabase().insert("purchases",null,v);}
 public void addPurchaseItem(long id,long itemId,String name,double qty,String unit,double rate){ContentValues v=new ContentValues();v.put("purchase_id",id);v.put("item_id",itemId);v.put("item_name",name);v.put("qty",qty);v.put("unit",unit);v.put("rate",rate);v.put("amount",qty*rate);getWritableDatabase().insert("purchase_items",null,v);if(itemId>0)getWritableDatabase().execSQL("UPDATE items SET stock=stock+?,purchase=? WHERE id=?",new Object[]{qty,rate,itemId});}
 public String setting(String k){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});String s="";if(c.moveToFirst())s=c.getString(0);c.close();return s;}
 public void setting(String k,String val){ContentValues v=new ContentValues();v.put("k",k);v.put("v",val);getWritableDatabase().insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
}
