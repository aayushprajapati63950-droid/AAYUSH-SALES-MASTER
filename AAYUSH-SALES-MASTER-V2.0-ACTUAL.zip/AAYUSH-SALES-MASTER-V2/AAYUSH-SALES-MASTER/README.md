# AAYUSH SALES MASTER V2.0

Vyapar-style retail billing foundation for AAYUSH SALES.

## Included
- Home, Dashboard, Items, Sale, Parties, Purchase, Payments, Expenses, Reports, Invoice History and Settings
- Offline SQLite storage
- Sale stock deduction
- Customer balance on credit sales
- Invoice print/PDF/image export
- Android Back navigation within the app

## Build
Open this folder in Android Studio and build the debug APK, or use the GitHub Actions workflow supplied in `.github/workflows/build-apk.yml`.
